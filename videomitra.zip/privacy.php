<?php require_once 'includes/config.php'; ?>
<?php require_once 'includes/header.php'; ?>
<body class="bg-gray-50 font-sans">
    <div class="flex md:flex-row-reverse flex-wrap">
        <!-- Main Content -->
        <div class="w-full md:w-4/5 bg-gray-100">
            <div class="container bg-white rounded-lg shadow-lg p-4 md:p-8 mx-auto my-4">
                <?php
                $result = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'privacy_policy'");
                $privacy_policy = $result->fetch_assoc()['setting_value'] ?? '<p>Privacy Policy not set.</p>';
                ?>
                <div class="prose max-w-none">
                    <?php echo $privacy_policy; ?>
                </div>
            </div>
        </div>
        <?php require_once 'includes/sidebar.php'; ?>
    </div>
<?php require_once 'includes/footer.php'; ?>