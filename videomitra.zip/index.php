<?php require_once 'includes/config.php'; ?>
<?php require_once 'includes/header.php'; ?>

<body class="bg-gray-50 font-sans leading-normal tracking-normal">

    <div class="flex md:flex-row-reverse flex-wrap">

        <!-- Main Content -->
        <div class="w-full md:w-4/5 bg-gray-100">
            <div class="container bg-white rounded-lg shadow-lg p-4 md:p-6 mx-auto">
                
                <!-- Slider Section - ADMIN CONTROLLED (UNCHANGED) -->
                <div class="relative w-full mb-8">
                    <div class="relative h-56 md:h-96 overflow-hidden rounded-lg">
                        <?php
                        // Database se sliders get karein - admin controlled
                        $sliders_result = $conn->query("SELECT * FROM sliders ORDER BY created_at DESC");
                        
                        if ($sliders_result->num_rows > 0):
                            $slide_index = 0;
                            while ($slider = $sliders_result->fetch_assoc()):
                        ?>
                        <div class="absolute inset-0 transition-opacity duration-700 ease-in-out <?php echo $slide_index === 0 ? 'opacity-100' : 'opacity-0'; ?>" data-slide="<?php echo $slide_index; ?>">
                            <img src="<?php echo htmlspecialchars($slider['image_url']); ?>" 
                                 class="w-full h-full object-cover"
                                 alt="Slider <?php echo $slide_index + 1; ?>"
                                 onerror="this.src='https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'">
                        </div>
                        <?php 
                            $slide_index++;
                            endwhile; 
                        else:
                        ?>
                        <!-- Default Sliders agar database empty hai -->
                        <div class="absolute inset-0 transition-opacity duration-700 ease-in-out opacity-100" data-slide="0">
                            <img src="uploads/sliders/slider1.jpg" 
                                 class="w-full h-full object-cover"
                                 alt="Slider 1"
                                 onerror="this.src='https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'">
                        </div>

                        <div class="absolute inset-0 transition-opacity duration-700 ease-in-out opacity-0" data-slide="1">
                            <img src="uploads/sliders/slider2.jpg" 
                                 class="w-full h-full object-cover"
                                 alt="Slider 2"
                                 onerror="this.src='https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'">
                        </div>

                        <div class="absolute inset-0 transition-opacity duration-700 ease-in-out opacity-0" data-slide="2">
                            <img src="uploads/sliders/slider3.jpg" 
                                 class="w-full h-full object-cover"
                                 alt="Slider 3"
                                 onerror="this.src='https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1120&q=80'">
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Slider Navigation Dots - Dynamic -->
                    <div class="flex justify-center mt-4 space-x-2" id="slider-dots">
                        <?php
                        $slider_count = $sliders_result->num_rows > 0 ? $sliders_result->num_rows : 3;
                        for ($i = 0; $i < $slider_count; $i++):
                        ?>
                        <button class="w-3 h-3 rounded-full <?php echo $i === 0 ? 'bg-purple-600' : 'bg-gray-300'; ?> slider-dot" 
                                data-slide-dot="<?php echo $i; ?>"></button>
                        <?php endfor; ?>
                    </div>
                </div>

                <!-- DOWNLOAD SECTION -->
                <section class="mb-12 bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-8 border border-purple-100">
                    <div class="text-center mb-8">
                        <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                            Download <span class="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Videos</span>
                        </h2>
                        <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                            Paste video URL below to download from any supported platform
                        </p>
                    </div>

                    <div class="max-w-2xl mx-auto">
                        <form id="downloadForm" class="space-y-4">
                            <div class="flex flex-col sm:flex-row gap-4">
                                <input 
                                    type="url" 
                                    id="videoUrl" 
                                    placeholder="Paste video URL here (e.g., https://youtube.com/watch?v=...)" 
                                    class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
                                    required
                                >
                                <button 
                                    type="submit" 
                                    class="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                                >
                                    <i class="fas fa-download mr-2"></i>
                                    Download
                                </button>
                            </div>
                        </form>
                        
                        <div id="downloadMessage" class="hidden mt-4 p-4 rounded-lg text-center"></div>
                    </div>
                </section>

                <!-- MODERN PLATFORMS SECTION -->
                <section class="mt-12">
                    <!-- Section Header -->
                    <div class="text-center mb-16">
                        <div class="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-purple-50 to-blue-50 text-purple-600 text-lg font-semibold mb-6 border border-purple-100 shadow-sm">
                            <i class="fas fa-check-circle mr-3 text-xl"></i>
                            Trusted by Millions Worldwide
                        </div>
                        <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                            Supported <span class="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Platforms</span>
                        </h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
                            Download videos from all popular platforms with crystal clear HD quality
                        </p>
                    </div>

                    <!-- Modern Platforms Grid - CLEAN IMAGES WITHOUT BACKGROUND BORDER -->
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                        <?php
                        // Database se platforms get karein
                        $result = $conn->query("SELECT * FROM platforms ORDER BY name ASC");
                        
                        // Platform URLs ko array mein store karein for JavaScript use
                        $platform_urls = array();
                        if ($result->num_rows > 0):
                            while ($row = $result->fetch_assoc()):
                                $target_url = !empty($row['custom_url']) ? $row['custom_url'] : $row['default_url'];
                                $logo_url = $row['logo_url'];
                                $platform_name = $row['name'];
                                
                                // Platform URLs ko array mein store karo
                                $platform_urls[$platform_name] = $target_url;
                                
                                // Platform colors for hover effects only
                                $platform_colors = [
                                    'youtube' => ['bg' => 'bg-red-500', 'hover' => 'hover:bg-red-600'],
                                    'facebook' => ['bg' => 'bg-blue-600', 'hover' => 'hover:bg-blue-700'],
                                    'instagram' => ['bg' => 'bg-pink-500', 'hover' => 'hover:bg-pink-600'],
                                    'tiktok' => ['bg' => 'bg-gray-900', 'hover' => 'hover:bg-black'],
                                    'pinterest' => ['bg' => 'bg-red-500', 'hover' => 'hover:bg-red-600'],
                                    'twitter' => ['bg' => 'bg-blue-400', 'hover' => 'hover:bg-blue-500'],
                                    'whatsapp' => ['bg' => 'bg-green-500', 'hover' => 'hover:bg-green-600'],
                                    'imgbb' => ['bg' => 'bg-purple-500', 'hover' => 'hover:bg-purple-600']
                                ];
                                
                                $platform_lower = strtolower($platform_name);
                                $color_info = ['bg' => 'bg-gray-600', 'hover' => 'hover:bg-gray-700'];
                                
                                foreach ($platform_colors as $key => $value) {
                                    if (strpos($platform_lower, $key) !== false) {
                                        $color_info = $value;
                                        break;
                                    }
                                }
                        ?>
                        <a href="<?php echo htmlspecialchars($target_url); ?>" 
                           target="_blank"
                           class="group block transform transition-all duration-500 hover:scale-105 hover:-translate-y-2 platform-link"
                           data-platform="<?php echo htmlspecialchars($platform_name); ?>">
                            <div class="relative bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-lg transition-all duration-300 group-hover:shadow-2xl group-hover:border-gray-200">
                                
                                <!-- Background Glow Effect -->
                                <div class="absolute inset-0 <?php echo $color_info['bg']; ?> opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity duration-500"></div>
                                
                                <!-- Platform Logo Container - CLEAN IMAGE WITHOUT BACKGROUND BORDER -->
                                <div class="relative mb-4">
                                    <div class="flex items-center justify-center">
                                        <!-- Clean Image - No Background Border -->
                                        <div class="w-16 h-16 flex items-center justify-center transform group-hover:scale-110 transition-transform duration-500">
                                            <?php if (!empty($logo_url)): ?>
                                                <img src="<?php echo htmlspecialchars($logo_url); ?>" 
                                                     alt="<?php echo htmlspecialchars($platform_name); ?>" 
                                                     class="w-full h-full object-contain"
                                                     onerror="this.style.display='none'; document.getElementById('fallback-<?php echo $row['id']; ?>').style.display='flex';">
                                            <?php endif; ?>
                                            
                                            <!-- Fallback Icon - Simple and Clean -->
                                            <div id="fallback-<?php echo $row['id']; ?>" 
                                                 class="<?php echo !empty($logo_url) ? 'hidden' : 'flex'; ?> items-center justify-center w-full h-full text-gray-400 text-2xl">
                                                <i class="fas fa-play"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Platform Name -->
                                <h3 class="font-bold text-gray-800 text-base mb-3 group-hover:text-gray-900 transition-colors duration-300">
                                    <?php echo htmlspecialchars($platform_name); ?>
                                </h3>
                                
                                <!-- Status Badge -->
                                <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-green-50 to-emerald-50 text-green-600 border border-green-100 group-hover:border-green-200 transition-colors duration-300">
                                    <div class="w-1.5 h-1.5 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                                    Supported
                                </div>

                                <!-- Hover Effect Line -->
                                <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 <?php echo $color_info['bg']; ?> group-hover:w-16 transition-all duration-500 rounded-t-full"></div>
                            </div>
                        </a>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <!-- Default Modern Platforms -->
                        <div class="col-span-6">
                            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 gap-6">
                                <div class="bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-lg hover:shadow-xl transition-all duration-300">
                                    <a href="#" class="block">
                                        <div class="w-16 h-16 flex items-center justify-center mx-auto mb-4">
                                            <i class="fab fa-youtube text-red-600 text-3xl"></i>
                                        </div>
                                        <h3 class="font-bold text-gray-800 text-base mb-2">YouTube</h3>
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-50 text-green-600 border border-green-100">
                                            <i class="fas fa-check text-xs mr-1"></i>Supported
                                        </span>
                                    </a>
                                </div>

                                <div class="bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-lg hover:shadow-xl transition-all duration-300">
                                    <a href="#" class="block">
                                        <div class="w-16 h-16 flex items-center justify-center mx-auto mb-4">
                                            <i class="fab fa-facebook text-blue-600 text-3xl"></i>
                                        </div>
                                        <h3 class="font-bold text-gray-800 text-base mb-2">Facebook</h3>
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-50 text-green-600 border border-green-100">
                                            <i class="fas fa-check text-xs mr-1"></i>Supported
                                        </span>
                                    </a>
                                </div>

                                <div class="bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-lg hover:shadow-xl transition-all duration-300">
                                    <a href="#" class="block">
                                        <div class="w-16 h-16 flex items-center justify-center mx-auto mb-4">
                                            <i class="fab fa-instagram text-pink-600 text-3xl"></i>
                                        </div>
                                        <h3 class="font-bold text-gray-800 text-base mb-2">Instagram</h3>
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-50 text-green-600 border border-green-100">
                                            <i class="fas fa-check text-xs mr-1"></i>Supported
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Stats Section -->
                    <div class="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
                        <div class="text-center p-6 bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl border border-purple-100">
                            <div class="text-3xl font-bold text-purple-600 mb-2">7+</div>
                            <div class="text-gray-700 font-semibold">Platforms</div>
                        </div>
                        <div class="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl border border-green-100">
                            <div class="text-3xl font-bold text-green-600 mb-2">HD</div>
                            <div class="text-gray-700 font-semibold">Quality</div>
                        </div>
                        <div class="text-center p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl border border-orange-100">
                            <div class="text-3xl font-bold text-orange-600 mb-2">Free</div>
                            <div class="text-gray-700 font-semibold">No Registration</div>
                        </div>
                    </div>
                </section>

            </div>
        </div>

        <?php require_once 'includes/sidebar.php'; ?>

    </div>

    <script>
    // Enhanced Slider with Admin Control (UNCHANGED)
    document.addEventListener('DOMContentLoaded', function() {
        const slides = document.querySelectorAll('[data-slide]');
        const dots = document.querySelectorAll('.slider-dot');
        const totalSlides = slides.length;
        
        if (totalSlides > 0) {
            let currentSlide = 0;
            let slideInterval;

            function showSlide(index) {
                slides.forEach(slide => {
                    slide.classList.remove('opacity-100');
                    slide.classList.add('opacity-0');
                });
                
                dots.forEach(dot => {
                    dot.classList.remove('bg-purple-600');
                    dot.classList.add('bg-gray-300');
                });
                
                slides[index].classList.remove('opacity-0');
                slides[index].classList.add('opacity-100');
                
                if (dots[index]) {
                    dots[index].classList.remove('bg-gray-300');
                    dots[index].classList.add('bg-purple-600');
                }
                
                currentSlide = index;
            }
            
            function startSlider() {
                if (totalSlides > 1) {
                    slideInterval = setInterval(() => {
                        let nextSlide = (currentSlide + 1) % totalSlides;
                        showSlide(nextSlide);
                    }, 5000);
                }
            }
            
            // Add click events to dots
            dots.forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    clearInterval(slideInterval);
                    showSlide(index);
                    startSlider();
                });
            });
            
            // Start slider
            showSlide(0);
            startSlider();
        }

        // Download Form Handler - AUTOMATIC PLATFORM DETECTION AND REDIRECTION TO ADMIN PANEL LINKS
        const downloadForm = document.getElementById('downloadForm');
        const videoUrlInput = document.getElementById('videoUrl');
        const downloadMessage = document.getElementById('downloadMessage');

        // Platform URLs from PHP (admin panel controlled)
        const platformUrls = <?php echo json_encode($platform_urls); ?>;

        downloadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const videoUrl = videoUrlInput.value.trim();
            
            if (!videoUrl) {
                showMessage('Please enter a video URL', 'error');
                return;
            }

            // Platform detect karo aur admin panel wala link khole
            const platformInfo = detectPlatformAndGetAdminLink(videoUrl);
            
            if (!platformInfo) {
                showMessage('This platform is not supported yet', 'error');
                return;
            }

            // Save to download history
            saveToHistory(videoUrl, platformInfo.name);
            
            // Redirect to admin panel controlled link
            showMessage(`Opening ${platformInfo.name} downloader...`, 'success');
            
            setTimeout(() => {
                // Admin panel ke link par redirect karo (new tab mein)
                window.open(platformInfo.url, '_blank');
                videoUrlInput.value = ''; // Clear input
            }, 1000);
        });

        // Platform detection function
        function detectPlatformAndGetAdminLink(url) {
            try {
                const urlObj = new URL(url);
                const hostname = urlObj.hostname.toLowerCase();
                
                // Platform detect karo aur admin panel wala link return karo
                const platformMappings = {
                    'youtube.com': 'YouTube',
                    'youtu.be': 'YouTube',
                    'facebook.com': 'Facebook',
                    'fb.watch': 'Facebook',
                    'instagram.com': 'Instagram',
                    'tiktok.com': 'TikTok',
                    'pinterest.com': 'Pinterest',
                    'twitter.com': 'Twitter',
                    'x.com': 'Twitter',
                    'whatsapp.com': 'WhatsApp',
                    'imgbb.com': 'ImageBB'
                };
                
                for (const [platformDomain, platformName] of Object.entries(platformMappings)) {
                    if (hostname.includes(platformDomain)) {
                        // Admin panel se platform ka link get karo
                        const adminLink = platformUrls[platformName];
                        if (adminLink) {
                            return {
                                name: platformName,
                                url: adminLink
                            };
                        }
                    }
                }
                
                return null;
            } catch (error) {
                return null;
            }
        }

        // Platform click tracking for history
        const platformLinks = document.querySelectorAll('.platform-link');
        platformLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                const platform = this.getAttribute('data-platform');
                const platformUrl = this.getAttribute('href');
                
                // Save platform visit to history
                saveToHistory(platformUrl, platform);
            });
        });

        function saveToHistory(url, platform = 'Direct URL') {
            const historyItem = {
                url: url,
                platform: platform,
                title: `Video from ${platform}`,
                date: new Date().toISOString(),
                thumbnail: getPlatformThumbnail(platform)
            };

            // Get existing history or initialize empty array
            let history = JSON.parse(localStorage.getItem('videoHistory')) || [];
            
            // Add new item to beginning of array
            history.unshift(historyItem);
            
            // Keep only last 50 items
            if (history.length > 50) {
                history = history.slice(0, 50);
            }
            
            // Save back to localStorage
            localStorage.setItem('videoHistory', JSON.stringify(history));
        }

        function getPlatformThumbnail(platform) {
            const thumbnails = {
                'YouTube': 'https://img.icons8.com/color/96/youtube-play.png',
                'Facebook': 'https://img.icons8.com/color/96/facebook-new.png',
                'Instagram': 'https://img.icons8.com/color/96/instagram-new.png',
                'TikTok': 'https://img.icons8.com/color/96/tiktok.png',
                'Pinterest': 'https://img.icons8.com/color/96/pinterest.png',
                'Twitter': 'https://img.icons8.com/color/96/twitter.png',
                'WhatsApp': 'https://img.icons8.com/color/96/whatsapp.png',
                'ImageBB': 'https://img.icons8.com/color/96/image.png'
            };
            
            return thumbnails[platform] || 'https://img.icons8.com/color/96/video.png';
        }

        function showMessage(message, type) {
            downloadMessage.textContent = message;
            downloadMessage.className = 'mt-4 p-4 rounded-lg text-center ';
            
            if (type === 'success') {
                downloadMessage.classList.add('bg-green-100', 'text-green-700', 'border', 'border-green-200');
            } else {
                downloadMessage.classList.add('bg-red-100', 'text-red-700', 'border', 'border-red-200');
            }
            
            downloadMessage.classList.remove('hidden');
            
            setTimeout(() => {
                downloadMessage.classList.add('hidden');
            }, 3000);
        }
    });
    </script>

<?php require_once 'includes/footer.php'; ?>