<?php
// Start session
session_start();

// Database connection
$host = '127.0.0.1';
$username = 'root'; 
$password = 'root';
$database = 'videomitra_db';

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle Add Platform
if (isset($_POST['add_platform'])) {
    $name = $_POST['name'];
    $default_url = $_POST['default_url'];
    $logo_url = $_POST['logo_url'];

    if (!empty($logo_url)) {
        $stmt = $conn->prepare("INSERT INTO platforms (name, logo_url, default_url) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $logo_url, $default_url);
        $stmt->execute();
    }
    
    echo "<script>window.location.href = 'platforms.php';</script>";
    exit;
}

// Handle Update Platform
if (isset($_POST['update_platform'])) {
    $id = $_POST['id'];
    $custom_url = $_POST['custom_url'];
    $logo_url = $_POST['logo_url'];
    
    $stmt = $conn->prepare("UPDATE platforms SET custom_url = ?, logo_url = ? WHERE id = ?");
    $stmt->bind_param("ssi", $custom_url, $logo_url, $id);
    $stmt->execute();
    echo "<script>window.location.href = 'platforms.php';</script>";
    exit;
}

// Handle Delete Platform
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    $stmt = $conn->prepare("DELETE FROM platforms WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "<script>window.location.href = 'platforms.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Platforms - VideoMitra</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    
    <!-- Admin Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="index.php" class="text-xl font-bold text-gray-800">VideoMitra Admin</a>
                </div>
                <nav class="flex space-x-4">
                    <a href="index.php" class="text-gray-600 hover:text-gray-900">Dashboard</a>
                    <a href="sliders.php" class="text-gray-600 hover:text-gray-900">Sliders</a>
                    <a href="platforms.php" class="text-blue-600 font-semibold">Platforms</a>
                    <a href="logout.php" class="text-red-600 hover:text-red-800">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="p-6">
        <h1 class="text-3xl font-bold mb-6">Manage Platforms</h1>

        <!-- Add Platform Form -->
        <div class="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 class="text-2xl font-semibold mb-4">Add New Platform</h2>
            <form method="POST" action="platforms.php">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Platform Name</label>
                            <input type="text" name="name" placeholder="e.g., YouTube, Instagram" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Default URL</label>
                            <input type="url" name="default_url" placeholder="https://example.com" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Logo URL *</label>
                            <input type="url" name="logo_url" placeholder="https://example.com/logo.png" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                            <p class="text-sm text-gray-500 mt-1">Direct image URL (PNG, JPG, SVG)</p>
                        </div>
                        
                        <div id="logoPreview" class="hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Logo Preview</label>
                            <img id="previewImg" class="w-20 h-20 object-contain border rounded-lg">
                        </div>
                    </div>
                </div>
                
                <button type="submit" name="add_platform" class="mt-6 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-200 font-semibold">
                    <i class="fas fa-plus mr-2"></i>Add Platform
                </button>
            </form>
        </div>

        <!-- Platforms Table -->
        <div class="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
            <h2 class="text-2xl font-semibold mb-4">Existing Platforms</h2>
            
            <?php
            $result = $conn->query("SELECT * FROM platforms ORDER BY id DESC");
            if ($result->num_rows === 0): ?>
                <div class="text-center py-8">
                    <i class="fas fa-layer-group text-4xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500">No platforms added yet</p>
                </div>
            <?php else: ?>
                <table class="w-full text-left">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-4 font-semibold">Logo</th>
                            <th class="p-4 font-semibold">Platform Name</th>
                            <th class="p-4 font-semibold">Logo URL</th>
                            <th class="p-4 font-semibold">Custom URL</th>
                            <th class="p-4 font-semibold">Default URL</th>
                            <th class="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-4">
                                <img src="<?php echo htmlspecialchars($row['logo_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($row['name']); ?>" 
                                     class="w-12 h-12 object-contain rounded-lg border"
                                     onerror="this.src='https://via.placeholder.com/48/cccccc/666666?text=LOGO'">
                            </td>
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($row['name']); ?></td>
                            <td class="p-4">
                                <form method="POST" action="platforms.php" class="flex items-center space-x-2">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="custom_url" value="<?php echo htmlspecialchars($row['custom_url']); ?>">
                                    <input type="url" name="logo_url" 
                                           value="<?php echo htmlspecialchars($row['logo_url']); ?>" 
                                           class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                           required>
                                    <button type="submit" name="update_platform" 
                                            class="bg-blue-600 text-white p-2 rounded hover:bg-blue-700 transition duration-200"
                                            title="Update Logo">
                                        <i class="fas fa-sync-alt"></i>
                                    </button>
                                </form>
                            </td>
                            <td class="p-4">
                                <form method="POST" action="platforms.php" class="flex items-center space-x-2">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="logo_url" value="<?php echo htmlspecialchars($row['logo_url']); ?>">
                                    <input type="url" name="custom_url" 
                                           value="<?php echo htmlspecialchars($row['custom_url']); ?>" 
                                           placeholder="Not set" 
                                           class="flex-1 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-transparent">
                                    <button type="submit" name="update_platform" 
                                            class="bg-green-600 text-white p-2 rounded hover:bg-green-700 transition duration-200"
                                            title="Save URL">
                                        <i class="fas fa-save"></i>
                                    </button>
                                </form>
                            </td>
                            <td class="p-4 text-sm text-gray-600">
                                <?php echo htmlspecialchars($row['default_url']); ?>
                            </td>
                            <td class="p-4">
                                <div class="flex space-x-2">
                                    <a href="platforms.php?delete=<?php echo $row['id']; ?>" 
                                       onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars($row['name']); ?>?')" 
                                       class="text-red-600 hover:text-red-800 p-2 rounded hover:bg-red-50 transition duration-200"
                                       title="Delete Platform">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script>
    // Logo URL preview functionality
    document.querySelector('input[name="logo_url"]').addEventListener('input', function(e) {
        const logoUrl = e.target.value;
        const preview = document.getElementById('logoPreview');
        const previewImg = document.getElementById('previewImg');
        
        if (logoUrl) {
            previewImg.src = logoUrl;
            preview.classList.remove('hidden');
            
            // Check if image loads successfully
            previewImg.onerror = function() {
                previewImg.src = 'https://via.placeholder.com/80/cccccc/666666?text=Invalid+URL';
            };
        } else {
            preview.classList.add('hidden');
        }
    });

    // Real-time preview for logo URL updates in table
    document.addEventListener('input', function(e) {
        if (e.target.name === 'logo_url' && e.target.closest('tbody')) {
            const logoUrl = e.target.value;
            const img = e.target.closest('tr').querySelector('td:first-child img');
            
            if (logoUrl && img) {
                img.src = logoUrl;
                
                img.onerror = function() {
                    img.src = 'https://via.placeholder.com/48/cccccc/666666?text=Invalid+URL';
                };
            }
        }
    });
    </script>

</body>
</html>