<?php
// admin/sliders.php - SIMPLE VERSION (Without Database)
require_once '../includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$upload_dir = "../uploads/";
$sliders = [];

// Create uploads directory if not exists
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Handle Add Slider (Simple file upload without database)
if (isset($_POST['add_slider'])) {
    if ($_FILES["slider_image"]["error"] === UPLOAD_ERR_OK) {
        $file_extension = pathinfo($_FILES["slider_image"]["name"], PATHINFO_EXTENSION);
        $unique_filename = uniqid() . '_' . time() . '.' . $file_extension;
        $target_file = $upload_dir . $unique_filename;

        $check = getimagesize($_FILES["slider_image"]["tmp_name"]);
        if($check !== false) {
            if (move_uploaded_file($_FILES["slider_image"]["tmp_name"], $target_file)) {
                header("Location: sliders.php?success=added");
                exit;
            } else {
                $error = "Sorry, there was an error uploading your file.";
            }
        } else {
            $error = "File is not an image.";
        }
    } else {
        $error = "File upload error.";
    }
}

// Handle Delete Slider
if (isset($_GET['delete'])) {
    $filename = $_GET['delete'];
    $file_path = $upload_dir . $filename;
    
    if (file_exists($file_path) && is_file($file_path)) {
        unlink($file_path);
        header("Location: sliders.php?success=deleted");
        exit;
    }
}

// Get list of slider images
if (is_dir($upload_dir)) {
    $files = scandir($upload_dir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            $file_path = $upload_dir . $file;
            if (is_file($file_path) && getimagesize($file_path)) {
                $sliders[] = [
                    'filename' => $file,
                    'image_url' => 'uploads/' . $file,
                    'created_at' => date('Y-m-d H:i:s', filemtime($file_path))
                ];
            }
        }
    }
}

require_once 'includes/header.php';
?>

<div class="p-6">
    <h1 class="text-3xl font-bold mb-6">Manage Sliders</h1>

    <!-- Success Messages -->
    <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php
            switch($_GET['success']) {
                case 'added': echo "✅ Slider image added successfully!"; break;
                case 'deleted': echo "✅ Slider image deleted successfully!"; break;
            }
            ?>
        </div>
    <?php endif; ?>

    <!-- Add Slider Form -->
    <div class="bg-white p-6 rounded-lg shadow-md mb-8">
        <h2 class="text-2xl font-semibold mb-4">Add New Slider Image</h2>
        <?php if(isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                ❌ <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="sliders.php" enctype="multipart/form-data">
            <div class="mb-4">
                <label for="slider_image" class="block text-gray-700 font-bold mb-2">Slider Image</label>
                <input type="file" name="slider_image" id="slider_image" accept="image/*" class="p-2 border rounded w-full" required>
                <p class="text-sm text-gray-500 mt-1">Recommended size: 1200x600 pixels</p>
            </div>
            <button type="submit" name="add_slider" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">
                <i class="fas fa-upload mr-2"></i>Upload Slider
            </button>
        </form>
    </div>

    <!-- Sliders List -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-2xl font-semibold mb-4">Current Sliders (<?php echo count($sliders); ?>)</h2>
        
        <?php if(count($sliders) > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($sliders as $slider): ?>
            <div class="relative group border border-gray-200 rounded-lg overflow-hidden bg-gray-50">
                <img src="../<?php echo htmlspecialchars($slider['image_url']); ?>" 
                     alt="Slider Image" 
                     class="w-full h-48 object-cover">
                <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-70 flex items-center justify-center transition-all duration-300">
                    <div class="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <a href="sliders.php?delete=<?php echo $slider['filename']; ?>" 
                           onclick="return confirm('Delete this slider?')" 
                           class="bg-red-600 text-white p-3 rounded-full hover:bg-red-700 inline-block mx-1">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </div>
                </div>
                <div class="p-3 bg-white">
                    <p class="text-sm text-gray-600 truncate"><?php echo $slider['filename']; ?></p>
                    <p class="text-xs text-gray-500"><?php echo $slider['created_at']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-12 bg-gray-50 rounded-lg">
            <i class="fas fa-images text-5xl text-gray-300 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-600 mb-2">No Sliders Added</h3>
            <p class="text-gray-500">Upload your first slider image above.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>