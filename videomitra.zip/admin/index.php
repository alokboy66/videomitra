<?php require_once 'includes/header.php'; ?>

<?php
// Fetch stats
$platforms_count_res = $conn->query("SELECT COUNT(id) as count FROM platforms");
$platforms_count = $platforms_count_res->fetch_assoc()['count'];

$sliders_count_res = $conn->query("SELECT COUNT(id) as count FROM sliders");
$sliders_count = $sliders_count_res->fetch_assoc()['count'];
?>

<div class="p-6">
    <h1 class="text-3xl font-bold mb-6">Dashboard</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        <!-- Total Platforms Card -->
        <div class="bg-white p-6 rounded-lg shadow-md flex items-center">
            <div class="bg-blue-500 text-white p-4 rounded-full">
                <i class="fas fa-list-alt fa-2x"></i>
            </div>
            <div class="ml-4">
                <h2 class="text-gray-600 text-lg">Total Platforms</h2>
                <p class="text-3xl font-bold"><?php echo $platforms_count; ?></p>
            </div>
        </div>
        
        <!-- Total Sliders Card -->
        <div class="bg-white p-6 rounded-lg shadow-md flex items-center">
            <div class="bg-green-500 text-white p-4 rounded-full">
                <i class="fas fa-images fa-2x"></i>
            </div>
            <div class="ml-4">
                <h2 class="text-gray-600 text-lg">Total Sliders</h2>
                <p class="text-3xl font-bold"><?php echo $sliders_count; ?></p>
            </div>
        </div>

        <!-- Static Downloads Card -->
        <div class="bg-white p-6 rounded-lg shadow-md flex items-center">
            <div class="bg-yellow-500 text-white p-4 rounded-full">
                <i class="fas fa-download fa-2x"></i>
            </div>
            <div class="ml-4">
                <h2 class="text-gray-600 text-lg">Total Downloads</h2>
                <p class="text-3xl font-bold">1,000+ <span class="text-sm">(Static)</span></p>
            </div>
        </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>