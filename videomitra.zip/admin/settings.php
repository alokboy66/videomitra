<?php
require_once 'includes/header.php';

// Handle Save Settings
if (isset($_POST['save_settings'])) {
    $share_link = $_POST['app_share_link'];
    $privacy_policy = $_POST['privacy_policy'];

    $stmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'app_share_link'");
    $stmt->bind_param("s", $share_link);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'privacy_policy'");
    $stmt->bind_param("s", $privacy_policy);
    $stmt->execute();
    
    $message = "Settings saved successfully!";
}

// Fetch current settings
$settings_res = $conn->query("SELECT * FROM settings");
$settings = [];
while($row = $settings_res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="p-6">
    <h1 class="text-3xl font-bold mb-6">App Settings</h1>

    <?php if(isset($message)): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded mb-6"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" action="settings.php" class="bg-white p-6 rounded-lg shadow-md">
        <!-- App Share Link -->
        <div class="mb-6">
            <label for="app_share_link" class="block text-lg font-semibold text-gray-700 mb-2">App Share Link</label>
            <input type="text" id="app_share_link" name="app_share_link" value="<?php echo htmlspecialchars($settings['app_share_link'] ?? ''); ?>" class="w-full p-2 border rounded" placeholder="https://your-app-url.com">
            <p class="text-sm text-gray-500 mt-1">This link will be used in the 'Share App' button on the user side.</p>
        </div>

        <!-- Privacy Policy -->
        <div class="mb-6">
            <label for="privacy_policy" class="block text-lg font-semibold text-gray-700 mb-2">Privacy & Policy</label>
            <textarea id="privacy_policy" name="privacy_policy" rows="15" class="w-full p-2 border rounded" placeholder="Enter your privacy policy content here..."><?php echo htmlspecialchars($settings['privacy_policy'] ?? ''); ?></textarea>
            <p class="text-sm text-gray-500 mt-1">This content will be displayed on the `privacy.php` page.</p>
        </div>

        <button type="submit" name="save_settings" class="bg-blue-500 text-white py-2 px-6 rounded hover:bg-blue-600">Save Settings</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>