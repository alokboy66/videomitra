<?php
// admin/sidebar.php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Mobile Menu Button -->
<div class="lg:hidden fixed top-4 left-4 z-50">
    <button id="mobileMenuBtn" class="bg-gray-800 text-white p-2 rounded-lg shadow-lg">
        <i class="fas fa-bars text-lg"></i>
    </button>
</div>

<!-- Sidebar -->
<div id="sidebar" class="w-64 bg-gradient-to-b from-gray-800 to-gray-900 text-white min-h-screen fixed lg:static transform -translate-x-full lg:translate-x-0 transition-transform duration-300 z-40">
    <!-- Close Button for Mobile -->
    <div class="lg:hidden flex justify-end p-4 border-b border-gray-700">
        <button id="closeSidebar" class="text-gray-400 hover:text-white">
            <i class="fas fa-times text-lg"></i>
        </button>
    </div>

    <!-- Header -->
    <div class="p-6 border-b border-gray-700">
        <div class="text-center">
            <h1 class="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                VideoMitra
            </h1>
            <p class="text-xs text-gray-400 mt-1">Admin Panel</p>
        </div>
    </div>

    <!-- User Info -->
    <div class="p-4 border-b border-gray-700">
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <i class="fas fa-user-cog text-white text-sm"></i>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-white truncate">
                    <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?>
                </p>
                <p class="text-xs text-gray-400">Administrator</p>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="p-4 flex-1">
        <div class="space-y-2">
            <!-- Dashboard -->
            <a href="index.php" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'index.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                <i class="fas fa-tachometer-alt w-5 text-center <?php echo $current_page == 'index.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                <span class="ml-3 font-medium">Dashboard</span>
                <?php if($current_page == 'index.php'): ?>
                    <i class="fas fa-chevron-right ml-auto text-xs"></i>
                <?php endif; ?>
            </a>

            <!-- Manage Platforms -->
            <a href="platforms.php" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'platforms.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                <i class="fas fa-layer-group w-5 text-center <?php echo $current_page == 'platforms.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                <span class="ml-3 font-medium">Manage Platforms</span>
                <?php if($current_page == 'platforms.php'): ?>
                    <i class="fas fa-chevron-right ml-auto text-xs"></i>
                <?php endif; ?>
            </a>

            <!-- Manage Sliders -->
            <a href="sliders.php" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'sliders.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                <i class="fas fa-images w-5 text-center <?php echo $current_page == 'sliders.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                <span class="ml-3 font-medium">Manage Sliders</span>
                <?php if($current_page == 'sliders.php'): ?>
                    <i class="fas fa-chevron-right ml-auto text-xs"></i>
                <?php endif; ?>
            </a>

            <!-- App Settings -->
            <a href="settings.php" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'settings.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                <i class="fas fa-cogs w-5 text-center <?php echo $current_page == 'settings.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                <span class="ml-3 font-medium">App Settings</span>
                <?php if($current_page == 'settings.php'): ?>
                    <i class="fas fa-chevron-right ml-auto text-xs"></i>
                <?php endif; ?>
            </a>

            <!-- View Website -->
            <a href="../index.php" target="_blank" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 hover:bg-gray-700 hover:translate-x-1 mt-4 border border-gray-600">
                <i class="fas fa-external-link-alt w-5 text-center text-green-400"></i>
                <span class="ml-3 font-medium">View Website</span>
                <i class="fas fa-arrow-up-right-from-square ml-auto text-xs text-green-400"></i>
            </a>

            <!-- Logout -->
            <a href="logout.php" 
               class="flex items-center py-3 px-4 rounded-lg transition-all duration-200 hover:bg-red-600 hover:translate-x-1 mt-4">
                <i class="fas fa-sign-out-alt w-5 text-center text-red-400"></i>
                <span class="ml-3 font-medium">Logout</span>
            </a>
        </div>
    </nav>

    <!-- Footer Stats -->
    <div class="p-4 border-t border-gray-700 mt-auto">
        <div class="text-center">
            <div class="flex justify-center space-x-4 text-xs text-gray-400 mb-2">
                <span class="flex items-center">
                    <i class="fas fa-circle text-green-500 mr-1"></i>
                    Online
                </span>
                <span>•</span>
                <span>v1.0</span>
            </div>
            <p class="text-xs text-gray-500">VideoMitra Admin</p>
        </div>
    </div>
</div>

<!-- Mobile Overlay -->
<div id="mobileOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden" onclick="toggleSidebar()"></div>

<script>
// Sidebar toggle functionality
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobileOverlay');
    
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
    
    // Prevent body scroll when sidebar is open
    document.body.classList.toggle('overflow-hidden');
}

// Initialize sidebar events
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeSidebar = document.getElementById('closeSidebar');
    const overlay = document.getElementById('mobileOverlay');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', toggleSidebar);
    }
    
    if (closeSidebar) {
        closeSidebar.addEventListener('click', toggleSidebar);
    }
    
    if (overlay) {
        overlay.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar when clicking on links (mobile)
    const sidebarLinks = document.querySelectorAll('#sidebar a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 1024) {
                toggleSidebar();
            }
        });
    });
    
    // Close sidebar on window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) {
            document.getElementById('sidebar').classList.remove('-translate-x-full');
            document.getElementById('mobileOverlay').classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        }
    });
});
</script>

<style>
/* Custom styles for better appearance */
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

/* Smooth transitions */
.transition-all {
    transition: all 0.3s ease;
}

/* Ensure proper z-index stacking */
.fixed {
    z-index: 40;
}

#mobileOverlay {
    z-index: 30;
}
</style>