<?php
require_once '../includes/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VideoMitra - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        @keyframes colorChange {
            0% { color: #7c3aed; }
            25% { color: #ec4899; }
            50% { color: #3b82f6; }
            75% { color: #10b981; }
            100% { color: #7c3aed; }
        }
        .animated-text {
            animation: colorChange 3s infinite;
        }
        .sidebar-link {
            transition: all 0.3s ease;
        }
        .sidebar-link:hover {
            transform: translateX(5px);
        }
        .active-link {
            background: linear-gradient(135deg, #7c3aed, #ec4899);
            color: white;
            border-left: 4px solid white;
        }
        /* Prevent body scroll when sidebar is open */
        body.sidebar-open {
            overflow: hidden;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Mobile Header -->
    <div class="lg:hidden bg-white shadow-sm border-b">
        <div class="flex items-center justify-between p-4">
            <div class="flex items-center">
                <button id="mobileMenuBtn" class="text-gray-600 mr-4">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <h1 class="text-xl font-bold animated-text">VideoMitra</h1>
                <span class="ml-2 bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">Admin</span>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm text-gray-600 hidden sm:block">
                    <i class="fas fa-user mr-1"></i>
                    <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                </span>
                <a href="logout.php" class="bg-red-500 text-white py-2 px-3 rounded-lg hover:bg-red-600 transition duration-200 text-sm">
                    <i class="fas fa-sign-out-alt mr-1"></i>
                    Logout
                </a>
            </div>
        </div>
    </div>

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div id="sidebar" class="w-64 bg-gradient-to-b from-gray-800 to-gray-900 text-white min-h-screen fixed lg:static transform -translate-x-full lg:translate-x-0 transition duration-300 z-40">
            <!-- Close Button for Mobile -->
            <div class="lg:hidden flex justify-end p-4 border-b border-gray-700">
                <button id="closeSidebar" class="text-gray-400 hover:text-white">
                    <i class="fas fa-times text-lg"></i>
                </button>
            </div>

            <!-- Desktop Header in Sidebar -->
            <div class="p-6 border-b border-gray-700">
                <div class="text-center">
                    <h1 class="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                        VideoMitra
                    </h1>
                    <p class="text-xs text-gray-400 mt-1">Admin Panel</p>
                </div>
            </div>

            <!-- User Info -->
            <div class="p-4 border-b border-gray-700">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                        <i class="fas fa-user-cog text-white text-sm"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-white truncate">
                            <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                        </p>
                        <p class="text-xs text-gray-400">Administrator</p>
                    </div>
                </div>
            </div>

            <!-- Navigation -->
            <nav class="p-4 flex-1">
                <div class="space-y-2">
                    <!-- Dashboard -->
                    <a href="index.php" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'index.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                        <i class="fas fa-tachometer-alt w-5 text-center <?php echo $current_page == 'index.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                        <span class="ml-3 font-medium">Dashboard</span>
                        <?php if($current_page == 'index.php'): ?>
                            <i class="fas fa-chevron-right ml-auto text-xs"></i>
                        <?php endif; ?>
                    </a>

                    <!-- Manage Platforms -->
                    <a href="platforms.php" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'platforms.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                        <i class="fas fa-layer-group w-5 text-center <?php echo $current_page == 'platforms.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                        <span class="ml-3 font-medium">Manage Platforms</span>
                        <?php if($current_page == 'platforms.php'): ?>
                            <i class="fas fa-chevron-right ml-auto text-xs"></i>
                        <?php endif; ?>
                    </a>

                    <!-- Manage Sliders -->
                    <a href="sliders.php" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'sliders.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                        <i class="fas fa-images w-5 text-center <?php echo $current_page == 'sliders.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                        <span class="ml-3 font-medium">Manage Sliders</span>
                        <?php if($current_page == 'sliders.php'): ?>
                            <i class="fas fa-chevron-right ml-auto text-xs"></i>
                        <?php endif; ?>
                    </a>

                    <!-- App Settings -->
                    <a href="settings.php" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 <?php echo $current_page == 'settings.php' ? 'bg-purple-600 shadow-lg shadow-purple-500/25' : 'hover:bg-gray-700 hover:translate-x-1'; ?>">
                        <i class="fas fa-cogs w-5 text-center <?php echo $current_page == 'settings.php' ? 'text-white' : 'text-gray-300'; ?>"></i>
                        <span class="ml-3 font-medium">App Settings</span>
                        <?php if($current_page == 'settings.php'): ?>
                            <i class="fas fa-chevron-right ml-auto text-xs"></i>
                        <?php endif; ?>
                    </a>

                    <!-- View Website -->
                    <a href="../index.php" target="_blank" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 hover:bg-gray-700 hover:translate-x-1 mt-4 border border-gray-600">
                        <i class="fas fa-external-link-alt w-5 text-center text-green-400"></i>
                        <span class="ml-3 font-medium">View Website</span>
                        <i class="fas fa-arrow-up-right-from-square ml-auto text-xs text-green-400"></i>
                    </a>

                    <!-- Logout -->
                    <a href="logout.php" 
                       class="sidebar-link flex items-center py-3 px-4 rounded-lg transition-all duration-200 hover:bg-red-600 hover:translate-x-1 mt-4">
                        <i class="fas fa-sign-out-alt w-5 text-center text-red-400"></i>
                        <span class="ml-3 font-medium">Logout</span>
                    </a>
                </div>
            </nav>

            <!-- Footer Stats -->
            <div class="p-4 border-t border-gray-700 mt-auto">
                <div class="text-center">
                    <div class="flex justify-center space-x-4 text-xs text-gray-400 mb-2">
                        <span class="flex items-center">
                            <i class="fas fa-circle text-green-500 mr-1"></i>
                            Online
                        </span>
                        <span>•</span>
                        <span>v1.0</span>
                    </div>
                    <p class="text-xs text-gray-500">VideoMitra Admin</p>
                </div>
            </div>
        </div>

        <!-- Mobile Overlay -->
        <div id="mobileOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden" onclick="toggleSidebar()"></div>

        <!-- Main Content -->
        <div class="flex-1 lg:ml-0 min-h-screen flex flex-col">
            <!-- Desktop Top Header -->
            <header class="bg-white shadow-md p-6 hidden lg:block">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800">
                            <?php
                            $page_titles = [
                                'index.php' => 'Dashboard',
                                'platforms.php' => 'Manage Platforms', 
                                'sliders.php' => 'Manage Sliders',
                                'settings.php' => 'App Settings'
                            ];
                            echo $page_titles[$current_page] ?? 'Admin Panel';
                            ?>
                        </h1>
                        <p class="text-gray-600 mt-1">
                            <i class="fas fa-home mr-1"></i>
                            Admin Panel / <?php echo $page_titles[$current_page] ?? 'Page'; ?>
                        </p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <div class="text-right">
                            <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($_SESSION['admin_username']); ?></p>
                            <p class="text-xs text-gray-500">Last login: <?php echo date('M j, Y g:i A'); ?></p>
                        </div>
                        <div class="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Content Area -->
            <main class="flex-1 p-4 lg:p-6">
                <!-- Content will be inserted here by individual pages -->

<script>
// Sidebar toggle functionality
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobileOverlay');
    const body = document.body;
    
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
    body.classList.toggle('sidebar-open');
}

// Initialize sidebar events
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeSidebar = document.getElementById('closeSidebar');
    const overlay = document.getElementById('mobileOverlay');
    
    // Mobile menu button
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar button
    if (closeSidebar) {
        closeSidebar.addEventListener('click', toggleSidebar);
    }
    
    // Overlay click
    if (overlay) {
        overlay.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar when clicking on links (mobile)
    const sidebarLinks = document.querySelectorAll('#sidebar a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 1024) {
                toggleSidebar();
            }
        });
    });
    
    // Close sidebar on window resize (if mobile becomes desktop)
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('mobileOverlay');
            const body = document.body;
            
            if (sidebar) sidebar.classList.remove('-translate-x-full');
            if (overlay) overlay.classList.add('hidden');
            body.classList.remove('sidebar-open');
        }
    });
    
    // Keyboard shortcut to close sidebar (Escape key)
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && window.innerWidth < 1024) {
            const sidebar = document.getElementById('sidebar');
            if (sidebar && !sidebar.classList.contains('-translate-x-full')) {
                toggleSidebar();
            }
        }
    });
    
    // Ensure sidebar is visible on desktop on page load
    if (window.innerWidth >= 1024) {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.remove('-translate-x-full');
        }
    }
});
</script>