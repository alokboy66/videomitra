<?php require_once 'includes/config.php'; ?>
<?php require_once 'includes/header.php'; ?>

<body class="bg-gray-50 font-sans">
    <div class="flex md:flex-row-reverse flex-wrap">
        <!-- Main Content -->
        <div class="w-full md:w-4/5 bg-gray-100">
            <div class="container bg-white rounded-lg shadow-lg p-4 md:p-8 mx-auto my-4">
                <h1 class="text-3xl font-bold text-gray-800 mb-6">Download History</h1>
                <p class="text-gray-600 mb-4">Your recently downloaded videos are stored in your browser. Clearing your browser data may remove this history.</p>

                <div id="history-container" class="space-y-4">
                    <!-- History items will be injected here by JavaScript -->
                </div>

                <div id="no-history" class="hidden text-center py-10 px-6 bg-gray-50 rounded-lg">
                    <i class="fas fa-history fa-3x text-gray-400 mb-4"></i>
                    <h2 class="text-xl font-semibold text-gray-700">No History Found</h2>
                    <p class="text-gray-500 mt-2">You haven't downloaded any videos yet.</p>
                </div>

            </div>
        </div>
        <?php require_once 'includes/sidebar.php'; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const historyContainer = document.getElementById('history-container');
        const noHistoryMessage = document.getElementById('no-history');
        // NOTE: The 'videoHistory' is a placeholder. A real download script would add items to this localStorage key.
        const history = JSON.parse(localStorage.getItem('videoHistory')) || [];

        if (history.length === 0) {
            noHistoryMessage.classList.remove('hidden');
        } else {
            history.forEach(item => {
                const historyItem = `
                    <div class="flex items-center bg-white border border-gray-200 rounded-lg shadow-sm p-4 hover:bg-gray-50 transition-colors duration-200">
                        <img src="${item.thumbnail || 'https://via.placeholder.com/150'}" alt="Video Thumbnail" class="w-24 h-24 object-cover rounded-md mr-4">
                        <div class="flex-1">
                            <h3 class="font-bold text-lg text-gray-800">${item.title || 'Video Title Not Available'}</h3>
                            <p class="text-sm text-gray-500">Downloaded on: ${new Date(item.date).toLocaleDateString()}</p>
                        </div>
                    </div>
                `;
                historyContainer.innerHTML += historyItem;
            });
        }
    });
    </script>
<?php require_once 'includes/footer.php'; ?>