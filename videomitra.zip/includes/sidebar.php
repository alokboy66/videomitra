<!-- Sidebar -->
<div id="sidebar" class="w-full md:w-1/5 bg-white shadow-lg p-4 fixed md:relative h-full -right-full md:right-auto transition-all duration-300 z-40">
    <nav class="mt-4">
        <a href="index.php" class="flex items-center py-3 px-4 text-gray-700 rounded-lg hover:bg-blue-500 hover:text-white transition-colors duration-200">
            <i class="fas fa-home w-6"></i>
            <span class="ml-3">Home</span>
        </a>
        <a href="history.php" class="flex items-center mt-2 py-3 px-4 text-gray-700 rounded-lg hover:bg-blue-500 hover:text-white transition-colors duration-200">
            <i class="fas fa-history w-6"></i>
            <span class="ml-3">Download History</span>
        </a>
        <?php
        $result = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_share_link'");
        $share_link = $result->fetch_assoc()['setting_value'] ?? '#';
        ?>
        <a href="<?php echo htmlspecialchars($share_link); ?>" target="_blank" class="flex items-center mt-2 py-3 px-4 text-gray-700 rounded-lg hover:bg-blue-500 hover:text-white transition-colors duration-200">
            <i class="fas fa-share-alt w-6"></i>
            <span class="ml-3">Share App</span>
        </a>
        <a href="privacy.php" class="flex items-center mt-2 py-3 px-4 text-gray-700 rounded-lg hover:bg-blue-500 hover:text-white transition-colors duration-200">
            <i class="fas fa-shield-alt w-6"></i>
            <span class="ml-3">Privacy Policy</span>
        </a>
    </nav>
</div>