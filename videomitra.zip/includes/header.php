<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VideoMitra - Your Video Downloading Partner</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-100">

<header class="bg-white shadow-md p-4 flex justify-between items-center">
    <h1 class="text-3xl font-bold animated-gradient">VideoMitra</h1>
    <button id="sidebar-toggle" class="md:hidden p-2 rounded-md hover:bg-gray-200">
        <i class="fas fa-bars fa-lg"></i>
    </button>
</header>