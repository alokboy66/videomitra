<script src="https://unpkg.com/flowbite@1.5.1/dist/flowbite.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>